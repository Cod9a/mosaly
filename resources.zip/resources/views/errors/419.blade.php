@extends('errors::minimal')

@section('title', __('Page Expirée'))
@section('code', '419')
@section('message', __('Page Expirée'))
