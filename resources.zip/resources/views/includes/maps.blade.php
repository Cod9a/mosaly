<!-- Google Map -->
		
<div class="maps {{ Route::currentRouteName() == 'conferences' ? 'conferences' : '' }} row">
	<div class="col-lg-6">
		<iframe src="https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d7930.548742420227!2d2.429025!3d6.358522!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0xac122d224f4656a!2sR%C3%A9sidences%20Mosaly%20Cotonou!5e0!3m2!1sfr!2sus!4v1635769705158!5m2!1sfr!2sus" style="border:0;" allowfullscreen="" loading="lazy" width="100%" height="500px"></iframe>
	</div>
	<div class="col-lg-6">
		<iframe src="https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d7930.490128511249!2d2.525464!3d6.362321000000001!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0x5eac567a89723856!2shotel%20Mosaly%20PK10!5e0!3m2!1sfr!2sus!4v1635769584025!5m2!1sfr!2sus" width="100%" height="500px" style="border:0;" allowfullscreen="" loading="lazy"></iframe>
	</div>
</div>