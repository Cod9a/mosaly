@component('mail::message')
# Le Complexe Mosaly a reçu un nouveau message.
@endcomponent