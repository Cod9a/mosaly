@component('mail::message')
# Hello,
Nous avons très-bien reçu votre message</b>. <br>

Cordialement,<br>
L'équipe Mosaly.
@endcomponent